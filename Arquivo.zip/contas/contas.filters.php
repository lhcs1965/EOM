<div class="col-sm-auto">
    <div class="card p-2">
        <small>
            <span class="h6">Situação:</span>
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-vencida" value="" onclick="set_fix_filter()" checked>
            Vencidas
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-quitada" value="" onclick="set_fix_filter()">
            Quitadas
        </small>
    </div>
</div>
<div class="col-sm-auto">
    <div class="card p-2">
        <small>
            <span class="h6">Vence:</span>
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-hoje" value="" onclick="set_fix_filter()" checked>
            Hoje
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-amanha" value="" onclick="set_fix_filter()" checked>
            Amanhã
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-semana" value="" onclick="set_fix_filter()" checked>
            Nesta semana
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-proxima" value="" onclick="set_fix_filter()" checked>
            Na próxima semana&#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-breve" value="" onclick="set_fix_filter()" checked>
            Em breve
        </small>
    </div>
</div>
<div class="col-sm-auto">
    <div class="card p-2">
        <small>
            <span class="h6">Somente:</span>
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-conta" value="" onclick="set_fix_filter()" >
            Sem Conta
            &#160;&#160;
            <input class="form-check-input" type="checkbox" id="cb-fornecedor" value="" onclick="set_fix_filter()" >
            Sem Fornecedor
        </small>
    </div>
</div>

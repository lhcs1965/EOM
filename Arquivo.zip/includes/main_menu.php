<div class="col-sm-auto">
    <div class="dropdown">
        <a href="#" class="text-light text-decoration-none dropdown-toggle" role="button" data-bs-toggle="dropdown">
            <?=$menu?>
        </a>
        <ul class="dropdown-menu">
            <?=$menu_html?>
        </ul>
    </div>
</div>

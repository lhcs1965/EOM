<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
    <title>FC - <?=$menu?></title>
    <link rel='stylesheet' href='css/bootstrap/bootstrap.min.css'>
    <!-- <link rel='stylesheet' href='css/datatables/dataTables.dataTables.css'> -->
    <link rel='stylesheet' href='css/datatables/dataTables.bootstrap5.css'>
    <link rel='stylesheet' href='css/custom.css'>
</head>

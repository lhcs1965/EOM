<script src='js/jquery-3.7.1.js'></script>
<script src='js/bootstrap/bootstrap.bundle.min.js'></script>
<script src='js/datatables/dataTables.js'></script>
<script src="js/datatables/dataTables.bootstrap5.js"></script>
<script src="js/datatables/moment.min.js"></script>
<!-- <script src="js/datatables/dateTime.js"></script> -->


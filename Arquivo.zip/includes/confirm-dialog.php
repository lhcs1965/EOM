<div class="modal" tabindex="-1" id="confirm-dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><span id="cd-header"></span></h5>
            </div>
            <div class="modal-body">
                <span id="cd-body"></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger"  data-bs-dismiss="modal" onclick="confirm()">Continuar</button>
                <button type="button" class="btn btn-warning" data-bs-dismiss="modal" >Cancelar</button>
            </div>
        </div>
    </div>
</div>
